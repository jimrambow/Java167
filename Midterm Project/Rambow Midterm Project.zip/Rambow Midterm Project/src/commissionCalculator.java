//Filename	Midterm Project
//Purpose 	To find the profit for a company after calculating a salespersons commission.
//@Author	James Rambow

import java.util.Scanner;

public class commissionCalculator {

	public static void main(String[] args) 
	{
		
		//Variable setting
		Scanner input = new Scanner(System.in);
		String status;
		double sales = 0;
		double partTimeRate = 3.5;
		double fullTimeRateLow = 5;
		double fullTimeRateHigh = 7.5;
		double commissionEarned = 0.0;
		String commisssionType = null;
		double profit;
		
		//Gathering input from user
		
		System.out.println("Please enter your status Part-Time (p) or Full-Time (f): ");
		status = input.nextLine();
		status = status.toLowerCase();
		
		System.out.println("How much did you make in sales?");
		sales = input.nextDouble();
		
		//Starting of calculations
		
		if (status.equals("p") && sales > 0) //Part Time Workers
		{
			commissionEarned = (sales * partTimeRate) / 100;
			commisssionType = "Rate Applied: 3.5%";
			status = "Part Time";
		}
			if (status.equals("f") && sales < 10000.00)//Full time low rate workers
			{
				commissionEarned = (sales * fullTimeRateLow) / 100;
				commisssionType = "Rate Applied: 5%";
				status = "Full Time";
				
			}
			else if  (status.equals("f") && sales >= 10000.00)//full time high rate workers
			{
				commissionEarned = (sales * fullTimeRateHigh) / 100;
				commisssionType = "Rate Applied: 7.5%";
				status = "Full Time";
			}
			
		profit = sales - commissionEarned;
		
		//Output of all information in order
		
		System.out.println(status);
		System.out.println(sales);
		System.out.println(commisssionType);
		System.out.println(commissionEarned);
		System.out.println(profit);
	}

}
