//FILENAME : PROGRAM 1
//TEACHER : A.JACKSON CPT 167
//AUTHOR : JIM RAMBOW



import java.util.Scanner;


public class Problem1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String userName = "";
		int yearsAttended;
		String itemName = "";
		double origPrice;
		int howMany;
		double discountPrice;
		double totalCost;
		
		System.out.println("Please enter your first name: ");
		userName = input.nextLine();
		
		System.out.println("How many years have you been in school: " + userName);
		yearsAttended = input.nextInt();
		input.nextLine();
		
		
		System.out.println("What item are you wanting to purchase: ");
		itemName = input.nextLine();
		
		System.out.println("What is its original price: ");
		origPrice = input.nextDouble();
		
		discountPrice = origPrice - (origPrice * 0.37);
		
		System.out.println("The new Price for this item with the discout is " + discountPrice);
		System.out.println("How many of these are you wanting to purchase: ");
		howMany = input.nextInt();
		
		totalCost = howMany * discountPrice;
		
		System.out.println("Let's summarize all of it.");
		System.out.println(userName);
		System.out.println(yearsAttended);
		System.out.println(itemName);
		System.out.println(origPrice);
		System.out.println(discountPrice);
		System.out.println(howMany);
		System.out.println(totalCost);
		
		
		
		
		
	}

}
